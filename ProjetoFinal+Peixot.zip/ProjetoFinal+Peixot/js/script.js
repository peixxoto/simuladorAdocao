let adotantes = JSON.parse(localStorage.getItem("adotantes")) || [];

document.getElementById("form-adocao").addEventListener("submit", function(event) {
    event.preventDefault();

    // Coleta os dados
    const nome = document.getElementById("nome").value.trim();
    const email = document.getElementById("email").value.trim();
    const telefone = document.getElementById("telefone").value.trim();
    const endereco = document.getElementById("endereco").value.trim();
    const tipoMoradia = document.getElementById("tipo-moradia").value;
    const tamanhoCasa = document.getElementById("tamanho-casa").value;
    const horariosCasa = document.getElementById("horarios-casa").value;
    const motivacao = document.getElementById("motivacao").value.trim();
    const animalDesejado = document.getElementById("animal").value;
    
    const outrosAnimais = document.querySelector("input[name='outros-animais']:checked");
    const criancas = document.querySelector("input[name='criancas']:checked");

    if (!outrosAnimais || !criancas) {
        alert("Responda todas as perguntas!");
        return;
    }

    // Avaliação de adoção
    let statusAdocao = "✅ Aprovado para adoção!";
    if (horariosCasa < 4) {
        statusAdocao = "⚠️ Atenção: Você passa pouco tempo em casa.";
    }
    if (motivacao.toLowerCase().includes("vigia") || motivacao.toLowerCase().includes("venda")) {
        statusAdocao = "❌ Não apto para adoção.";
    }

    // Adicionar ao array
    const adotante = { nome, email, telefone, endereco, tipoMoradia, tamanhoCasa, horariosCasa, outrosAnimais: outrosAnimais.value, criancas: criancas.value, motivacao, animalDesejado, statusAdocao };
    adotantes.push(adotante);
    localStorage.setItem("adotantes", JSON.stringify(adotantes));

    // Exibir resultado
    document.getElementById("resultado").innerHTML = `<p>${nome}, ${statusAdocao}</p>`;

    atualizarLista();
    document.getElementById("form-adocao").reset();
});

function atualizarLista() {
    const listaAdotantes = document.getElementById("lista-adotantes");
    listaAdotantes.innerHTML = "";

    adotantes.forEach((adotante, index) => {
        const item = document.createElement("li");
        item.innerHTML = `${adotante.nome} (${adotante.animalDesejado}) - ${adotante.statusAdocao}`;
        
        const botaoRemover = document.createElement("button");
        botaoRemover.textContent = "Remover";
        botaoRemover.classList.add("remove-btn");
        botaoRemover.onclick = () => {
            adotantes.splice(index, 1);
            localStorage.setItem("adotantes", JSON.stringify(adotantes));
            atualizarLista();
        };

        item.appendChild(botaoRemover);
        listaAdotantes.appendChild(item);
    });
}

atualizarLista();
